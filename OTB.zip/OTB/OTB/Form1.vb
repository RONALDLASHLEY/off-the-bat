﻿'Ronald Lashley
'Lincoln University of PA
'Computer Science Major (Class of 2017)
'CSC-498: Topics in Computer Science
'email : lashleyronald1@gmail.com

Imports Excel = Microsoft.Office.Interop.Excel
Imports System.Net.Mail
Imports Microsoft.Office.Interop.Excel

Public Class Form1

    Dim APP As New Excel.Application
    Dim worksheet As Excel.Worksheet
    Dim workbook As Excel.Workbook
    Dim Player As String
    Dim Email As String
    Dim available1 As String
    Dim unavailable1 As String
    Dim PStartTime As Integer
    Dim PEndTime As Integer
    Dim Roster As String
    Dim Emails As String
    Dim FromEmail As String
    Dim Password As String

    Public Workbooks As Object

    Private Sub Send_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Send.Click

        'select email server and Send practice message
        Try
            Dim Smtp_Server As New SmtpClient
            Dim mail As New MailMessage()
            FromEmail = TextBox2.Text
            Password = TextBox4.Text
            Smtp_Server.UseDefaultCredentials = False
            Smtp_Server.Credentials = New Net.NetworkCredential(FromEmail, Password)
            'Smtp_Server.Credentials = New Net.NetworkCredential("lashleyronald1@gmail.com", "------")
            Smtp_Server.Port = 587 'outgoing messagee
            Smtp_Server.EnableSsl = True
            If ComboBox2.SelectedItem = "Gmail" Then
                Smtp_Server.Host = "smtp.gmail.com"
            ElseIf ComboBox2.SelectedItem = "Outlook" Then
                Smtp_Server.Host = "smtp.mail.outlook.com"
            ElseIf ComboBox2.SelectedItem = "AOL" Then
                Smtp_Server.Host = "smtp.aol.com"
            Else
                MsgBox("Select a server")
            End If
            MsgBox("Server selected")
            mail = New MailMessage() ' create new message
            mail.From = New MailAddress(FromEmail) ' from email address (user email)
            mail.To.Add(Emails) ' to email address(es)
            mail.Subject = "Practice Time from Off the Bat Application " ' email subject
            mail.IsBodyHtml = False
            mail.Body = (RichTextBox3.Text + vbNewLine + vbNewLine + "Thank you for using Off the Bat" + vbNewLine + vbNewLine + vbNewLine + vbNewLine + "Off the Bat 2017") ' Body of email based on message text box
            Smtp_Server.Send(mail) ' send email
            MsgBox("Mail Sent")
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MsgBox("Welcome to Off the Bat!")
    End Sub

    Sub count()
        ' count number of players available and unavailable & display number in label
        available1 = RichTextBox1.Lines.Count - 1
        unavailable1 = RichTextBox2.Lines.Count - 1
        Label7.Text = ("Avaliable:  " + available1)
        Label8.Text = ("Unavailable: " + unavailable1)
    End Sub

    Private Sub SelectRoster_Click(sender As Object, e As EventArgs) Handles SelectRoster.Click
        ' Select Excel file using file dialog
        OpenFileDialog1.Title = "Please Select a File"
        OpenFileDialog1.InitialDirectory = "C:temp"
        OpenFileDialog1.ShowDialog()
    End Sub

    Private Sub OpenFileDialog1_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk
        'file select/open dialog box
        Dim strm As System.IO.Stream

        strm = OpenFileDialog1.OpenFile()
        Roster = OpenFileDialog1.FileName.ToString()

        If Not (strm Is Nothing) Then

            'insert code to read the file data
            workbook = APP.Workbooks.Open(Roster)
            worksheet = workbook.Worksheets("sheet1")

            'MsgBox(Roster)
            strm.Close()
            MsgBox("File is selected")
        End If
    End Sub

    Sub excelParser()
        'Parse excel file to get data
        Dim x As Integer = 2 'starts at name
        Dim y As Integer = 1 'starts at name
        Dim j As Integer = 100 ' number of entries
        'Dim z As Integer
        Dim Day As String

        For i = 0 To j
            Player = worksheet.Cells(x, y).Text
            If Player = Player Then
                Day = worksheet.Cells(x, y + 1).Text
                If Day = ComboBox1.SelectedItem Then ' get day of week to search for in excel file
                    PStartTime = worksheet.Cells(x, y + 2).Value 'get player start time
                    PEndTime = worksheet.Cells(x, y + 3).Value 'get player end time
                    Emails = Email
                    Email = worksheet.Cells(x, y + 4).Text 'get email address
                    Emails = Emails + "; " + Email
                    availability()
                    clear()
                Else
                    clear()
                End If
                x = x + 1 ' next row
            End If
        Next
        count()
        Missing()
    End Sub

    Sub checkError()
        If TextBox1.Text > TextBox3.Text Or TextBox1.Text = TextBox3.Text Then
            MsgBox("Error!!!!!!!!! Coaches start time for practice must be before coaches end time for practice")
            TextBox1.Text = Nothing
            TextBox3.Text = Nothing
        ElseIf PStartTime > PEndTime Or PStartTime = PEndTime Then
            MsgBox("Error!!!!!!!!! Player start time for class must be before player end time for class")
        Else
            MsgBox("Valid Entries")
        End If
    End Sub

    Sub availability()
        'Check availability based on player start and end time and coaches coach start and end time
        If TextBox1.Text = PStartTime And TextBox3.Text = PEndTime Then
            unavailable()
        ElseIf TextBox1.Text = PStartTime Or TextBox3.Text = PEndTime Then
            unavailable()
        ElseIf TextBox1.Text < PStartTime And TextBox3.Text > PEndTime Then
            unavailable()
        ElseIf TextBox1.Text > PStartTime And TextBox3.Text < PEndTime Then
            unavailable()
        ElseIf PStartTime < TextBox1.Text And PEndTime < TextBox3.Text And PEndTime > TextBox1.Text Then
            unavailable()
        ElseIf PStartTime > TextBox1.Text And PEndTime > TextBox3.Text And PStartTime < TextBox3.Text Then
            unavailable()
        ElseIf PStartTime < TextBox1.Text And PEndTime < TextBox3.Text And PEndTime > TextBox1.Text Then
            unavailable()
        Else
            available()
            RichTextBox3.Text = ("Message: " + vbNewLine + "Practice will be on " + ComboBox1.SelectedItem + " from " + TextBox1.Text + " to " + TextBox3.Text + ".")
        End If
    End Sub

    Private Sub Generate_Click(sender As Object, e As EventArgs) Handles Generate.Click
        'Generate Button
        clear()
        checkError()
        excelParser()
    End Sub

    Private Sub Clear_Button_Click(sender As Object, e As EventArgs) Handles Clear_Button.Click
        'Clear Button
        TextBox1.Text = Nothing
        TextBox3.Text = Nothing
        RichTextBox1.Text = Nothing
        RichTextBox2.Text = Nothing
        RichTextBox3.Text = Nothing
        Label8.Text = ("Unavailable")
        Label7.Text = ("Available")
    End Sub

    Sub clear()
        'Clear data for player Start and End Time
        PStartTime = 0
        PEndTime = 1
    End Sub

    Sub unavailable()
        'Unavailable List
        RichTextBox2.AppendText(Player + vbNewLine)
    End Sub

    Sub available()
        'Available List
        RichTextBox1.AppendText(Player + vbNewLine)
    End Sub

    Sub Missing()
        'Limit
        If NumericUpDown1.Text < unavailable1 Then
            MsgBox("More than " + NumericUpDown1.Text + " will be missing. You should look at a different time slot for practice.")
        Else
            MsgBox("This is a valid time for practice but " + unavailable1 + " will be missing.")
        End If
    End Sub

    Sub SignOut()
        FromEmail = Nothing
        Password = Nothing
        Label19.Text = Nothing
        SignIn.Text = "Sign In"
        MsgBox("Signed Out")
    End Sub

    Private Sub SignIn_Click(sender As Object, e As EventArgs) Handles SignIn.Click
        'Sign In
        If SignIn.Text = "Sign In" Then
            FromEmail = TextBox2.Text
            Password = TextBox4.Text
            TextBox2.Text = Nothing
            TextBox4.Text = Nothing
            MsgBox("Signed In")
            Label19.Text = ("Welcome " + FromEmail)
            SignIn.Text = "Sign Out"
        Else
            SignOut()
        End If
    End Sub
End Class